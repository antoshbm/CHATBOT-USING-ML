import React from 'react';
import { SendIcon } from 'lucide-react';

interface ChatInputProps {
  input: string;
  setInput: (value: string) => void;
  handleSend: (e: React.FormEvent) => void;
  isTyping: boolean;
}

export function ChatInput({ input, setInput, handleSend, isTyping }: ChatInputProps) {
  return (
    <div className="bg-white border-t p-4">
      <form onSubmit={handleSend} className="max-w-4xl mx-auto flex gap-4">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message..."
          disabled={isTyping}
          className="flex-1 rounded-xl border border-gray-300 px-4 py-2
            focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent
            disabled:opacity-50 disabled:cursor-not-allowed
            transition-shadow duration-200
            shadow-sm hover:shadow-md"
        />
        <button
          type="submit"
          disabled={!input.trim() || isTyping}
          className={`
            bg-indigo-600 text-white rounded-xl px-6 py-2
            flex items-center gap-2
            transition-all duration-200 transform
            ${!input.trim() || isTyping
              ? 'opacity-50 cursor-not-allowed'
              : 'hover:bg-indigo-700 hover:scale-[1.02] active:scale-[0.98]'}
            shadow-lg shadow-indigo-600/25
          `}
        >
          <SendIcon className="w-4 h-4" />
          Send
        </button>
      </form>
    </div>
  );
}