import React, { useState } from 'react';
import { User } from '../types';
import { UserCircle, Shield, Building2 } from 'lucide-react'; // Changed Hospital to Building2
import { LoginHeader } from './login/LoginHeader';
import { RoleSelector } from './login/RoleSelector';
import { LoginInput } from './login/LoginInput';

interface LoginFormProps {
  onLogin: (user: User) => void;
}

export default function LoginForm({ onLogin }: LoginFormProps) {
  const [username, setUsername] = useState('');
  const [role, setRole] = useState<'staff' | 'patient'>('patient');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      setIsLoading(true);
      // Simulate loading
      await new Promise(resolve => setTimeout(resolve, 800));
      onLogin({ username, role });
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        {/* Floating cards background effect */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-4 -left-4 w-24 h-24 bg-blue-100 rounded-full opacity-50 animate-float"></div>
          <div className="absolute top-1/4 -right-8 w-32 h-32 bg-indigo-100 rounded-full opacity-50 animate-float-delayed"></div>
          <div className="absolute bottom-1/4 -left-12 w-40 h-40 bg-purple-100 rounded-full opacity-50 animate-float"></div>
        </div>

        <div className="relative bg-white/80 backdrop-blur-lg rounded-2xl shadow-xl p-8 space-y-8">
          <LoginHeader />
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <LoginInput
              value={username}
              onChange={setUsername}
              icon={<UserCircle className="w-5 h-5 text-gray-400" />}
            />

            <RoleSelector
              role={role}
              onRoleChange={setRole}
              options={[
                { value: 'patient', label: 'Patient', icon: <UserCircle className="w-4 h-4" /> },
                { value: 'staff', label: 'Staff', icon: <Shield className="w-4 h-4" /> }
              ]}
            />

            <button
              type="submit"
              disabled={isLoading || !username.trim()}
              className={`
                w-full flex items-center justify-center gap-2 py-3 px-4 
                rounded-xl text-sm font-semibold text-white
                transition-all duration-300 transform
                ${isLoading 
                  ? 'bg-indigo-400 cursor-wait' 
                  : 'bg-indigo-600 hover:bg-indigo-700 hover:scale-[1.02] active:scale-[0.98]'}
                shadow-lg shadow-indigo-600/25
                disabled:opacity-50 disabled:cursor-not-allowed
              `}
            >
              {isLoading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Connecting...
                </>
              ) : (
                <>
                  <Building2 className="w-5 h-5" />
                  Start Chat with Sana
                </>
              )}
            </button>
          </form>

          <div className="text-center text-sm text-gray-500">
            By continuing, you agree to our{' '}
            <a href="#" className="text-indigo-600 hover:text-indigo-700">Terms of Service</a>
            {' '}and{' '}
            <a href="#" className="text-indigo-600 hover:text-indigo-700">Privacy Policy</a>
          </div>
        </div>
      </div>
    </div>
  );
}