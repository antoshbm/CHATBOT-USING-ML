import React from 'react';
import { Stethoscope } from 'lucide-react';

export function LoginHeader() {
  return (
    <div className="flex flex-col items-center space-y-4">
      <div className="relative">
        <div className="absolute inset-0 bg-indigo-100 rounded-full blur-lg transform scale-150 opacity-50"></div>
        <div className="relative bg-gradient-to-br from-indigo-500 to-purple-500 rounded-full p-4">
          <Stethoscope className="w-8 h-8 text-white" />
        </div>
      </div>
      
      <div className="text-center">
        <h1 className="text-2xl font-bold text-gray-900">Welcome to Sana</h1>
        <p className="mt-2 text-gray-600">
          Your AI-powered healthcare assistant
        </p>
      </div>

      <div className="flex items-center gap-4 text-sm text-gray-500">
        <div className="flex items-center gap-1">
          <span className="w-2 h-2 bg-green-500 rounded-full"></span>
          24/7 Support
        </div>
        <div className="flex items-center gap-1">
          <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
          Instant Response
        </div>
      </div>
    </div>
  );
}