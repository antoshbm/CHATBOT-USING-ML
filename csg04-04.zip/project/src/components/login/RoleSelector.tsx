import React from 'react';

interface RoleSelectorProps {
  role: string;
  onRoleChange: (role: 'staff' | 'patient') => void;
  options: {
    value: 'staff' | 'patient';
    label: string;
    icon: React.ReactNode;
  }[];
}

export function RoleSelector({ role, onRoleChange, options }: RoleSelectorProps) {
  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700">
        Select your role
      </label>
      <div className="grid grid-cols-2 gap-3">
        {options.map((option) => (
          <button
            key={option.value}
            type="button"
            onClick={() => onRoleChange(option.value)}
            className={`
              flex items-center justify-center gap-2 py-2.5 px-4
              rounded-xl text-sm font-medium
              transition-all duration-200 transform
              ${role === option.value
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25 scale-[1.02]'
                : 'bg-white text-gray-700 border border-gray-300 hover:border-indigo-300 hover:bg-indigo-50'}
            `}
          >
            {option.icon}
            {option.label}
          </button>
        ))}
      </div>
    </div>
  );
}