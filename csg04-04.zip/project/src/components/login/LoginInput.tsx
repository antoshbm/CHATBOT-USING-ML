import React from 'react';

interface LoginInputProps {
  value: string;
  onChange: (value: string) => void;
  icon: React.ReactNode;
}

export function LoginInput({ value, onChange, icon }: LoginInputProps) {
  return (
    <div className="space-y-2">
      <label htmlFor="username" className="block text-sm font-medium text-gray-700">
        Username
      </label>
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          {icon}
        </div>
        <input
          type="text"
          id="username"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="block w-full pl-10 pr-4 py-2.5 text-gray-900 placeholder-gray-500
            border border-gray-300 rounded-xl
            focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent
            transition-shadow duration-200
            shadow-sm hover:shadow-md"
          placeholder="Enter your username"
          required
        />
      </div>
    </div>
  );
}