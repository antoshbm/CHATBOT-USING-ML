import { QueryCategory } from '../../types';

export const emergencyContactQueries: QueryCategory = {
  keywords: [
    'emergency contact', 'emergency number', 'helpline',
    'urgent contact', 'emergency line', 'hotline',
    'after hours', 'emergency support', 'crisis'
  ],
  responses: [
    'For medical emergencies, please call our 24/7 emergency hotline: (555) 911-0000',
    'Our emergency response team is available 24/7. Main ER contact: (555) 911-0001',
    'For mental health emergencies, contact our crisis hotline: (555) 911-0002',
    'Save these numbers for quick access:\n- General Emergency: (555) 911-0000\n- Ambulance: (555) 911-0003\n- Poison Control: (555) 911-0004',
    'Our emergency contact center can connect you with the appropriate department immediately.',
    'In case of life-threatening emergencies, always call 911 first.',
  ],
};