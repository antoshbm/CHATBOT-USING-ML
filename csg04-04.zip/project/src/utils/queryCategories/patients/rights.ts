import { QueryCategory } from '../../types';

export const patientRightsQueries: QueryCategory = {
  keywords: [
    'patient rights', 'medical rights', 'privacy',
    'HIPAA', 'confidentiality', 'patient advocacy',
    'complaints', 'grievances', 'patient protection'
  ],
  responses: [
    'Your rights as a patient include:\n- Privacy protection\n- Access to medical records\n- Informed consent\n- Quality care',
    'We protect your privacy through:\n- Strict HIPAA compliance\n- Secure medical records\n- Confidential communications',
    'To file a complaint or concern, contact our patient advocate: (555) 123-4612.',
    'Request medical records through our health information department.',
  ],
};