import { QueryCategory } from '../../../types';

export const patientCommunicationQueries: QueryCategory = {
  keywords: [
    'patient communication', 'language services',
    'interpreter', 'translation', 'sign language',
    'patient portal', 'contact nurse', 'call button',
    'family updates', 'medical updates'
  ],
  responses: [
    'Communication services:\n- 24/7 interpreter services\n- Sign language support\n- Patient portal access\n- Family update system',
    'Access your health information through our patient portal.',
    'For language assistance: (555) 123-4617.',
    'Nurses respond to call buttons within minutes.',
  ],
};