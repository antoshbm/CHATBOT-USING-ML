import { QueryCategory } from '../../../types';

export const patientComfortQueries: QueryCategory = {
  keywords: [
    'patient comfort', 'room temperature', 'bed adjustment',
    'noise level', 'quiet hours', 'entertainment',
    'TV', 'wifi', 'reading material', 'patient amenities'
  ],
  responses: [
    'Room amenities include:\n- Adjustable bed\n- TV/Entertainment\n- WiFi access\n- Reading materials',
    'Quiet hours: 9 PM - 7 AM daily.',
    'For room comfort issues: (555) 123-4618.',
    'Additional pillows and blankets available upon request.',
  ],
};