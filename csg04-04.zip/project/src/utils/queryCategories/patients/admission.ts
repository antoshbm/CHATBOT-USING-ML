import { QueryCategory } from '../../types';

export const admissionQueries: QueryCategory = {
  keywords: [
    'admission process', 'get admitted', 'hospital admission',
    'pre-admission', 'patient intake', 'admission requirements',
    'overnight stay', 'hospital entry', 'patient registration'
  ],
  responses: [
    'Admission process includes:\n- Registration\n- Medical history review\n- Insurance verification\n- Room assignment',
    'Required documents for admission:\n- Photo ID\n- Insurance card\n- Medical records\n- Current medications list',
    'For planned admissions, contact our admissions office: (555) 123-4610.',
    'Emergency admissions are handled 24/7 through our ER department.',
  ],
};