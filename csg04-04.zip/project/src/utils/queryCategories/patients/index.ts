export * from './admission';
export * from './discharge';
export * from './rights';
export * from './transportation';
export * from './meals';
export * from './support';
export * from './belongings';
export * from './communication';
export * from './comfort';
export * from './feedback';

import { QueryCategory } from '../../../types';
import { admissionQueries } from './admission';
import { dischargeQueries } from './discharge';
import { patientRightsQueries } from './rights';
import { transportationQueries } from './transportation';
import { patientMealQueries } from './meals';
import { patientSupportQueries } from './support';
import { patientBelongingsQueries } from './belongings';
import { patientCommunicationQueries } from './communication';
import { patientComfortQueries } from './comfort';
import { patientFeedbackQueries } from './feedback';

export const patientQueries: QueryCategory = {
  keywords: [
    ...admissionQueries.keywords,
    ...dischargeQueries.keywords,
    ...patientRightsQueries.keywords,
    ...transportationQueries.keywords,
    ...patientMealQueries.keywords,
    ...patientSupportQueries.keywords,
    ...patientBelongingsQueries.keywords,
    ...patientCommunicationQueries.keywords,
    ...patientComfortQueries.keywords,
    ...patientFeedbackQueries.keywords,
    'patient', 'patient care', 'patient services'
  ],
  responses: [
    'Our patient services cover all aspects of your hospital stay.',
    'For general patient inquiries, contact our patient services desk: (555) 123-4620.',
  ],
};