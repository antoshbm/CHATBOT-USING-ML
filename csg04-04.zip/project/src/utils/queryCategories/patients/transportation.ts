import { QueryCategory } from '../../types';

export const transportationQueries: QueryCategory = {
  keywords: [
    'patient transport', 'medical transport',
    'wheelchair service', 'hospital shuttle',
    'patient pickup', 'transport assistance',
    'mobility help', 'getting to hospital'
  ],
  responses: [
    'Transportation services include:\n- Wheelchair assistance\n- Hospital shuttles\n- Medical transport\n- Emergency ambulance',
    'Free shuttle service available:\n- Between hospital buildings\n- From parking areas\n- To public transit',
    'For non-emergency medical transport: (555) 123-4613.',
    'Wheelchair assistance available at all entrances.',
  ],
};