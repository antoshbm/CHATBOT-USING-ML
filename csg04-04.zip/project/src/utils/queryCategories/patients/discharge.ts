import { QueryCategory } from '../../types';

export const dischargeQueries: QueryCategory = {
  keywords: [
    'discharge', 'leaving hospital', 'going home',
    'post-hospital care', 'discharge instructions',
    'follow-up care', 'after hospital', 'release'
  ],
  responses: [
    'Discharge process includes:\n- Final medical evaluation\n- Medication instructions\n- Follow-up appointments\n- Care instructions',
    'Before discharge, you\'ll receive:\n- Written care instructions\n- Prescription medications\n- Follow-up schedule\n- Emergency contacts',
    'Our care coordinators help plan your transition home.',
    'For questions after discharge, call: (555) 123-4611.',
  ],
};