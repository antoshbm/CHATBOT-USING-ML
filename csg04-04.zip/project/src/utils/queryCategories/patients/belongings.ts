import { QueryCategory } from '../../../types';

export const patientBelongingsQueries: QueryCategory = {
  keywords: [
    'personal belongings', 'valuables', 'patient property',
    'lost and found', 'safe storage', 'what to bring',
    'patient items', 'storage locker', 'personal items'
  ],
  responses: [
    'Recommended items to bring:\n- Comfortable clothes\n- Personal care items\n- Insurance cards\n- Current medications',
    'Valuables should be:\n- Sent home with family\n- Stored in room safe\n- Listed in belongings inventory',
    'Lost and found: Contact security at (555) 123-4616.',
    'We provide basic toiletries if needed.',
  ],
};