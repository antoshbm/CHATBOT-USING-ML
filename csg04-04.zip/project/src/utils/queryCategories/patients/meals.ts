import { QueryCategory } from '../../types';

export const patientMealQueries: QueryCategory = {
  keywords: [
    'patient meals', 'hospital food', 'dietary needs',
    'special diet', 'meal service', 'food allergies',
    'meal times', 'nutrition', 'dietary restrictions'
  ],
  responses: [
    'Our meal service provides:\n- Special diet options\n- Allergen-free meals\n- Cultural preferences\n- Nutritionist consultation',
    'Meal times:\n- Breakfast: 7-9 AM\n- Lunch: 11:30-1:30 PM\n- Dinner: 5-7 PM',
    'For dietary requirements, contact nutrition services: (555) 123-4614.',
    'All meals are prepared under strict dietary guidelines.',
  ],
};