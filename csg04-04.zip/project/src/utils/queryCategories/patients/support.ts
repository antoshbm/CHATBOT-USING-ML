import { QueryCategory } from '../../types';

export const patientSupportQueries: QueryCategory = {
  keywords: [
    'patient support', 'counseling', 'social services',
    'support groups', 'patient assistance', 'care coordination',
    'patient resources', 'financial assistance', 'social worker'
  ],
  responses: [
    'Support services include:\n- Social workers\n- Support groups\n- Financial counseling\n- Care coordination',
    'We offer assistance with:\n- Insurance navigation\n- Financial aid applications\n- Community resources\n- Home care planning',
    'Contact our patient support team: (555) 123-4615.',
    'Support groups available for various conditions.',
  ],
};