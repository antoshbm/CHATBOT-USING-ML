import { QueryCategory } from '../../../types';

export const patientFeedbackQueries: QueryCategory = {
  keywords: [
    'patient feedback', 'satisfaction survey', 'complaints',
    'suggestions', 'patient experience', 'review',
    'rate service', 'patient opinion', 'improvement'
  ],
  responses: [
    'Share your feedback through:\n- Patient surveys\n- Online reviews\n- Feedback forms\n- Patient advocate',
    'We value your input for improving our services.',
    'To submit feedback: (555) 123-4619.',
    'All feedback is reviewed by our quality improvement team.',
  ],
};