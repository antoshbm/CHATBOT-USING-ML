import { QueryCategory } from '../../types';

export const recordQueries: QueryCategory = {
  keywords: ['records', 'report', 'results', 'medical history', 'documents', 'test results'],
  responses: [
    'Medical records can be accessed through your patient portal account.',
    'To request physical copies of your medical records, please visit our Medical Records department.',
    'Test results are typically available within 48-72 hours through your patient portal.',
    'For urgent test results, please contact your healthcare provider directly.',
  ],
};