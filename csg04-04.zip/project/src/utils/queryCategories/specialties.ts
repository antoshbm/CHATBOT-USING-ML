import { QueryCategory } from '../../types';

export const specialtyQueries: QueryCategory = {
  keywords: ['specialist', 'cardiology', 'orthopedics', 'pediatrics', 'neurology', 'dermatology', 'oncology'],
  responses: [
    'We offer various specialty departments including cardiology, orthopedics, pediatrics, and more.',
    'To schedule with a specialist, please obtain a referral from your primary care physician.',
    'Our specialty clinics are located in the East Wing of the hospital.',
    'You can view our specialists\' profiles and availability on our website.',
  ],
};