// Base categories
export * from './appointments';
export * from './emergency';
export * from './billing';
export * from './facilities';
export * from './prescriptions';
export * from './covid';
export * from './records';
export * from './visiting';
export * from './doctors';
export * from './emergencyContacts';
export * from './diseases';
export * from './symptoms';
export * from './wellness';
export * from './registration';
export * from './ambulance';
export * from './parking';
export * from './timings';

// Specialty categories
export * from './specialties';

// Management categories
export * from './management';

// Patient categories
export * from './patients';