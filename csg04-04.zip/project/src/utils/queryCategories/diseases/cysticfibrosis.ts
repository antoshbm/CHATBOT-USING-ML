import { QueryCategory } from '../../types';

export const cysticFibrosisQueries: QueryCategory = {
  keywords: [
    'cystic fibrosis', 'CF', 'mucus', 'lung infection',
    'genetic disorder', 'breathing problems CF'
  ],
  responses: [
    'CF care includes:\n- Airway clearance\n- Infection prevention\n- Nutritional support\n- Gene therapy options',
    'Our CF Center provides:\n- Specialized treatments\n- Regular monitoring\n- Family support\nInfo: (555) 123-4722.',
  ],
};