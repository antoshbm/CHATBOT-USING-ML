import { QueryCategory } from '../../types';

export const arthritisQueries: QueryCategory = {
  keywords: [
    'arthritis', 'joint pain', 'rheumatoid', 'osteoarthritis',
    'joint inflammation', 'joint stiffness', 'arthritis pain'
  ],
  responses: [
    'Arthritis treatment options:\n- Pain management\n- Physical therapy\n- Joint protection\n- Medication therapy',
    'Our rheumatology department offers:\n- Joint assessments\n- Treatment planning\n- Pain management\nSchedule: (555) 123-4705',
  ],
};