import { QueryCategory } from '../../types';

export const chronicFatigueQueries: QueryCategory = {
  keywords: [
    'chronic fatigue', 'CFS', 'ME', 'fatigue syndrome',
    'myalgic encephalomyelitis', 'post-viral fatigue'
  ],
  responses: [
    'CFS symptoms include:\n- Severe fatigue\n- Sleep problems\n- Pain\n- Cognitive issues\nSchedule: (555) 123-4723.',
    'Our CFS management includes:\n- Symptom relief\n- Activity pacing\n- Sleep hygiene\n- Support services',
  ],
};