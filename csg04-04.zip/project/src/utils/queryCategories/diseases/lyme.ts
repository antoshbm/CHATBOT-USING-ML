import { QueryCategory } from '../../types';

export const lymeQueries: QueryCategory = {
  keywords: [
    'lyme disease', 'tick-borne', 'lyme',
    'tick bite', 'bulls eye rash'
  ],
  responses: [
    'Lyme symptoms include:\n- Rash\n- Fever\n- Joint pain\n- Fatigue\nSchedule testing: (555) 123-4733',
    'Our Lyme Center offers:\n- Early detection\n- Antibiotic therapy\n- Chronic care\n- Prevention education',
  ],
};