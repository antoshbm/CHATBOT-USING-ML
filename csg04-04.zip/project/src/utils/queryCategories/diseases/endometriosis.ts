import { QueryCategory } from '../../types';

export const endometriosisQueries: QueryCategory = {
  keywords: [
    'endometriosis', 'endo', 'pelvic pain',
    'menstrual problems', 'fertility issues'
  ],
  responses: [
    'Endometriosis symptoms:\n- Pelvic pain\n- Heavy periods\n- Fertility issues\n- Fatigue\nSchedule: (555) 123-4739.',
    'Our Women\'s Health Center offers:\n- Pain management\n- Hormone therapy\n- Surgical options\n- Fertility support',
  ],
};