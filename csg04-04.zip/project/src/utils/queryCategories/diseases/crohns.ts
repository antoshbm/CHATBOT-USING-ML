import { QueryCategory } from '../../types';

export const crohnsQueries: QueryCategory = {
  keywords: [
    'crohns disease', 'inflammatory bowel', 'IBD',
    'intestinal inflammation', 'crohns symptoms'
  ],
  responses: [
    'Crohn\'s symptoms include:\n- Abdominal pain\n- Diarrhea\n- Weight loss\n- Fatigue\nSchedule: (555) 123-4725',
    'Our IBD Center provides:\n- Disease management\n- Nutritional support\n- Medication therapy\n- Surgery options',
  ],
};