import { QueryCategory } from '../../types';

export const respiratoryQueries: QueryCategory = {
  keywords: [
    'asthma', 'COPD', 'emphysema', 'bronchitis',
    'breathing problems', 'respiratory disease', 'lung disease'
  ],
  responses: [
    'Respiratory emergency signs:\n- Severe shortness of breath\n- Blue lips/fingernails\n- Inability to speak\nSeek immediate care!',
    'Our pulmonary clinic provides:\n- Breathing treatments\n- Inhaler education\n- Lung function tests\nAppointments: (555) 123-4704',
  ],
};