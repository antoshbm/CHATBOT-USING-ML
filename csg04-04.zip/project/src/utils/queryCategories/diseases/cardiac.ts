import { QueryCategory } from '../../types';

export const heartDiseaseQueries: QueryCategory = {
  keywords: [
    'heart disease', 'heart attack', 'cardiac', 'chest pain',
    'coronary artery', 'heart failure', 'cardiovascular'
  ],
  responses: [
    'Heart attack symptoms - seek immediate help if you experience:\n- Chest pain/pressure\n- Shortness of breath\n- Pain in arms/jaw\n- Cold sweats\nCall 911 immediately!',
    'Our cardiology department provides:\n- 24/7 emergency cardiac care\n- Heart disease management\n- Cardiac rehabilitation\nContact: (555) 123-4700',
  ],
};