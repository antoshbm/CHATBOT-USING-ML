import { QueryCategory } from '../../types';

export const cancerQueries: QueryCategory = {
  keywords: [
    'cancer', 'tumor', 'oncology', 'chemotherapy',
    'radiation', 'cancer treatment', 'malignant'
  ],
  responses: [
    'Our cancer center provides:\n- Early detection\n- Chemotherapy\n- Radiation therapy\n- Support services\nContact: (555) 123-4702',
    'Cancer support includes:\n- Treatment planning\n- Pain management\n- Counseling services\n- Support groups',
  ],
};