import { QueryCategory } from '../../types';

export const dengueQueries: QueryCategory = {
  keywords: [
    'dengue fever', 'dengue', 'breakbone fever',
    'mosquito-borne', 'dengue symptoms'
  ],
  responses: [
    'Dengue symptoms include:\n- High fever\n- Severe pain\n- Bleeding\n- Shock\nSeek immediate care!',
    'Our Tropical Disease Unit provides:\n- Testing\n- Treatment\n- Monitoring\nContact: (555) 123-4736.',
  ],
};