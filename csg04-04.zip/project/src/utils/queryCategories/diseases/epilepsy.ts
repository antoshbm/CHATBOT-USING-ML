import { QueryCategory } from '../../types';

export const epilepsyQueries: QueryCategory = {
  keywords: [
    'epilepsy', 'seizures', 'convulsions',
    'epileptic', 'seizure disorder'
  ],
  responses: [
    'For seizure emergencies:\n- Call 911\n- Time the seizure\n- Clear the area\n- Stay with person',
    'Our Epilepsy Center offers:\n- Seizure monitoring\n- Medication management\n- Surgery options\nInfo: (555) 123-4731',
  ],
};