import { QueryCategory } from '../../types';

export const msQueries: QueryCategory = {
  keywords: [
    'multiple sclerosis', 'MS', 'demyelinating disease',
    'neurological disorder', 'ms symptoms', 'ms treatment'
  ],
  responses: [
    'MS symptoms vary and may include:\n- Vision problems\n- Fatigue\n- Numbness\n- Balance issues\nContact MS Clinic: (555) 123-4721.',
    'Our MS Center provides:\n- Disease management\n- Infusion therapy\n- Rehabilitation\n- Research trials',
  ],
};