import { QueryCategory } from '../../types';

export const leukemiaQueries: QueryCategory = {
  keywords: [
    'leukemia', 'blood cancer', 'bone marrow',
    'acute leukemia', 'chronic leukemia'
  ],
  responses: [
    'Our Cancer Center provides:\n- Chemotherapy\n- Bone marrow transplant\n- Clinical trials\n- Support services',
    'Leukemia treatment includes:\n- Regular monitoring\n- Blood products\n- Targeted therapy\nContact: (555) 123-4732',
  ],
};