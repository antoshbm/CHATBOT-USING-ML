import { QueryCategory } from '../../types';

export const strokeQueries: QueryCategory = {
  keywords: [
    'stroke', 'brain attack', 'cerebral', 'paralysis',
    'stroke symptoms', 'TIA', 'mini stroke'
  ],
  responses: [
    'Stroke symptoms (FAST):\n- Face drooping\n- Arm weakness\n- Speech difficulty\n- Time to call 911\nImmediate care is critical!',
    'Our stroke unit offers:\n- 24/7 emergency care\n- Rehabilitation services\n- Prevention education\nInfo: (555) 123-4703',
  ],
};