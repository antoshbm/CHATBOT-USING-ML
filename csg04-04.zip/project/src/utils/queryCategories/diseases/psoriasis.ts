import { QueryCategory } from '../../types';

export const psoriasisQueries: QueryCategory = {
  keywords: [
    'psoriasis', 'skin condition', 'psoriatic',
    'skin patches', 'scalp psoriasis'
  ],
  responses: [
    'Psoriasis treatments include:\n- Topical therapy\n- Light therapy\n- Systemic medications\n- Biologics',
    'Our Dermatology Center offers:\n- Customized treatment\n- Flare management\n- Clinical trials\nSchedule: (555) 123-4727',
  ],
};