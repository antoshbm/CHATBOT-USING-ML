import { QueryCategory } from '../../types';

export const anemiaQueries: QueryCategory = {
  keywords: [
    'anemia', 'iron deficiency', 'sickle cell',
    'low blood count', 'hemoglobin'
  ],
  responses: [
    'Anemia symptoms include:\n- Fatigue\n- Weakness\n- Shortness of breath\n- Dizziness\nSchedule: (555) 123-4729.',
    'Our Hematology Center offers:\n- Blood testing\n- Iron therapy\n- Transfusions\n- Treatment plans',
  ],
};