import { QueryCategory } from '../../types';

export const liverQueries: QueryCategory = {
  keywords: [
    'liver disease', 'hepatitis', 'cirrhosis',
    'fatty liver', 'liver function', 'liver problems'
  ],
  responses: [
    'Liver disease signs:\n- Jaundice\n- Abdominal pain\n- Fatigue\n- Dark urine\nSchedule testing: (555) 123-4709',
    'Our liver center offers:\n- Liver function tests\n- Treatment options\n- Dietary counseling\n- Support services',
  ],
};