import { QueryCategory } from '../../types';

export const alzheimersQueries: QueryCategory = {
  keywords: [
    'alzheimers', 'dementia', 'memory loss', 'cognitive decline',
    'forgetfulness', 'memory problems', 'cognitive impairment'
  ],
  responses: [
    'Early Alzheimer\'s signs:\n- Memory loss\n- Confusion\n- Behavior changes\n- Language problems\nSchedule assessment: (555) 123-4707',
    'Our memory clinic provides:\n- Cognitive testing\n- Treatment options\n- Family support\n- Care planning',
  ],
};