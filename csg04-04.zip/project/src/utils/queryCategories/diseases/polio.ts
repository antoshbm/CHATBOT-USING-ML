import { QueryCategory } from '../../types';

export const polioQueries: QueryCategory = {
  keywords: [
    'polio', 'post-polio syndrome', 'PPS',
    'poliomyelitis', 'muscle weakness'
  ],
  responses: [
    'Post-polio care includes:\n- Physical therapy\n- Pain management\n- Mobility aids\n- Support services',
    'Our Neurology Center provides:\n- Symptom management\n- Rehabilitation\n- Support groups\nSchedule: (555) 123-4738.',
  ],
};