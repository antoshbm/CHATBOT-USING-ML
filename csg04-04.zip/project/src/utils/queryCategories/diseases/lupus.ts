import { QueryCategory } from '../../types';

export const lupusQueries: QueryCategory = {
  keywords: [
    'lupus', 'SLE', 'systemic lupus', 'autoimmune disease',
    'lupus symptoms', 'lupus treatment'
  ],
  responses: [
    'Lupus symptoms include:\n- Joint pain\n- Rash\n- Fatigue\n- Fever\nContact: (555) 123-4724.',
    'Our Lupus Center offers:\n- Disease monitoring\n- Treatment plans\n- Flare management\n- Support groups',
  ],
};