import { QueryCategory } from '../../types';

export const immunizationQueries: QueryCategory = {
  keywords: [
    'immunization', 'vaccination', 'vaccine', 'shots',
    'booster shots', 'preventive vaccines',
    'immunization schedule', 'flu shot'
  ],
  responses: [
    'Vaccination services:\n- Routine immunizations\n- Travel vaccines\n- Flu shots\n- COVID-19 vaccines',
    'Our immunization clinic provides:\n- Vaccine consultations\n- Updated schedules\n- Record management\nSchedule: (555) 123-4716',
  ],
};