import { QueryCategory } from '../../types';

export const huntingtonsQueries: QueryCategory = {
  keywords: [
    'huntingtons disease', 'HD', 'genetic disorder',
    'movement disorder', 'chorea'
  ],
  responses: [
    'Huntington\'s symptoms include:\n- Movement changes\n- Cognitive decline\n- Mood changes\n- Balance problems',
    'Our HD Center provides:\n- Genetic counseling\n- Symptom management\n- Family support\nInfo: (555) 123-4728',
  ],
};