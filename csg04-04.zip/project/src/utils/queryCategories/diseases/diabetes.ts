import { QueryCategory } from '../../types';

export const diabetesQueries: QueryCategory = {
  keywords: [
    'diabetes', 'blood sugar', 'insulin', 'diabetic',
    'type 1 diabetes', 'type 2 diabetes', 'glucose'
  ],
  responses: [
    'Diabetes warning signs:\n- Excessive thirst\n- Frequent urination\n- Unexplained weight loss\n- Fatigue\nSchedule a screening: (555) 123-4701',
    'Our diabetes care includes:\n- Blood sugar monitoring\n- Insulin management\n- Nutrition counseling\n- Regular check-ups',
  ],
};