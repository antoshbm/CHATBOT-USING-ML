import { QueryCategory } from '../../types';

export const breathingQueries: QueryCategory = {
  keywords: [
    'breathing problems', 'shortness of breath', 'dyspnea',
    'breathing difficulty', 'respiratory distress',
    'breathlessness', 'breathing issues'
  ],
  responses: [
    'Emergency breathing symptoms:\n- Severe shortness of breath\n- Chest pain\n- Blue lips or face\nCall 911 immediately!',
    'Our respiratory clinic offers:\n- Breathing assessments\n- Pulmonary function tests\n- Treatment plans\nSchedule: (555) 123-4714',
  ],
};