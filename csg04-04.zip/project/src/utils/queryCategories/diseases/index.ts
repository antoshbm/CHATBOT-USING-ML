export * from './cardiac';
export * from './diabetes';
export * from './cancer';
export * from './stroke';
export * from './respiratory';
export * from './arthritis';
export * from './hypertension';
export * from './alzheimers';
export * from './kidney';
export * from './liver';
export * from './mental';
export * from './obesity';
export * from './hiv';
export * from './breathing';
export * from './infectious';
export * from './immunization';

import { QueryCategory } from '../../types';
import { heartDiseaseQueries } from './cardiac';
import { diabetesQueries } from './diabetes';
import { cancerQueries } from './cancer';
import { strokeQueries } from './stroke';
import { respiratoryQueries } from './respiratory';
import { arthritisQueries } from './arthritis';
import { hypertensionQueries } from './hypertension';
import { alzheimersQueries } from './alzheimers';
import { kidneyQueries } from './kidney';
import { liverQueries } from './liver';
import { mentalHealthQueries } from './mental';
import { obesityQueries } from './obesity';
import { hivAidsQueries } from './hiv';
import { breathingQueries } from './breathing';
import { infectiousQueries } from './infectious';
import { immunizationQueries } from './immunization';

export const diseaseQueries: QueryCategory = {
  keywords: [
    ...heartDiseaseQueries.keywords,
    ...diabetesQueries.keywords,
    ...cancerQueries.keywords,
    ...strokeQueries.keywords,
    ...respiratoryQueries.keywords,
    ...arthritisQueries.keywords,
    ...hypertensionQueries.keywords,
    ...alzheimersQueries.keywords,
    ...kidneyQueries.keywords,
    ...liverQueries.keywords,
    ...mentalHealthQueries.keywords,
    ...obesityQueries.keywords,
    ...hivAidsQueries.keywords,
    ...breathingQueries.keywords,
    ...infectiousQueries.keywords,
    ...immunizationQueries.keywords,
    'disease', 'condition', 'illness'
  ],
  responses: [
    'Please specify your health concern for accurate information. Our specialists can help with various conditions.',
    'For immediate medical concerns, please contact emergency services or visit our ER.',
  ],
};