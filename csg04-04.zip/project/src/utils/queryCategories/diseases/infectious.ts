import { QueryCategory } from '../../types';

export const infectiousQueries: QueryCategory = {
  keywords: [
    'infectious disease', 'infection', 'contagious',
    'bacterial infection', 'viral infection',
    'communicable disease', 'infectious condition'
  ],
  responses: [
    'Our infectious disease unit handles:\n- Diagnosis and treatment\n- Disease management\n- Prevention strategies\n- Outbreak control',
    'Infection services include:\n- Testing and diagnosis\n- Treatment plans\n- Isolation protocols\nContact: (555) 123-4715',
  ],
};