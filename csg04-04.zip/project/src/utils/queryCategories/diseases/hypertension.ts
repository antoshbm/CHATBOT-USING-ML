import { QueryCategory } from '../../types';

export const hypertensionQueries: QueryCategory = {
  keywords: [
    'hypertension', 'high blood pressure', 'blood pressure',
    'hypertensive', 'pressure reading', 'BP'
  ],
  responses: [
    'High BP warning signs:\n- Severe headache\n- Vision problems\n- Chest pain\n- Difficulty breathing\nSeek immediate care!',
    'Blood pressure management:\n- Regular monitoring\n- Medication management\n- Lifestyle counseling\nInfo: (555) 123-4706',
  ],
};