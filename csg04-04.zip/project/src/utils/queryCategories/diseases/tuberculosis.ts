import { QueryCategory } from '../../types';

export const tuberculosisQueries: QueryCategory = {
  keywords: [
    'tuberculosis', 'TB', 'lung infection',
    'mycobacterium', 'TB testing'
  ],
  responses: [
    'TB services include:\n- Skin testing\n- Chest X-rays\n- Treatment plans\n- Contact tracing',
    'Our TB Clinic provides:\n- Medication therapy\n- Regular monitoring\n- Prevention\nContact: (555) 123-4734',
  ],
};