import { QueryCategory } from '../../types';

export const obesityQueries: QueryCategory = {
  keywords: [
    'obesity', 'weight management', 'weight loss', 'BMI',
    'bariatric', 'weight control', 'overweight',
    'weight reduction', 'metabolic syndrome'
  ],
  responses: [
    'Our weight management center offers:\n- Medical evaluation\n- Nutritional counseling\n- Exercise programs\n- Bariatric surgery options',
    'Comprehensive weight services:\n- BMI assessment\n- Personalized diet plans\n- Behavioral therapy\nContact: (555) 123-4712',
  ],
};