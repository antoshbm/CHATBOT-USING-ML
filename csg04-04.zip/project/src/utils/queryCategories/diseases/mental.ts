import { QueryCategory } from '../../types';

export const mentalHealthQueries: QueryCategory = {
  keywords: [
    'mental health', 'depression', 'anxiety', 'panic attacks',
    'bipolar', 'schizophrenia', 'mental illness', 'psychiatric',
    'suicide', 'mental crisis', 'therapy', 'counseling'
  ],
  responses: [
    'Mental health crisis? Call our 24/7 crisis line: (555) 123-4710\nImmediate help for:\n- Suicidal thoughts\n- Severe anxiety\n- Mental health emergencies',
    'Our mental health services include:\n- Individual therapy\n- Group counseling\n- Medication management\n- Crisis intervention\nSchedule: (555) 123-4711',
  ],
};