import { QueryCategory } from '../../types';

export const malariaQueries: QueryCategory = {
  keywords: [
    'malaria', 'mosquito disease', 'plasmodium',
    'malaria symptoms', 'malaria treatment'
  ],
  responses: [
    'Malaria symptoms include:\n- Fever cycles\n- Chills\n- Sweating\n- Fatigue\nUrgent care needed!',
    'Our Tropical Medicine Center offers:\n- Rapid testing\n- Treatment plans\n- Prevention\nInfo: (555) 123-4737.',
  ],
};