import { QueryCategory } from '../../types';

export const hivAidsQueries: QueryCategory = {
  keywords: [
    'HIV', 'AIDS', 'HIV testing', 'HIV treatment',
    'antiretroviral', 'HIV prevention', 'PrEP', 'PEP',
    'HIV care', 'AIDS symptoms'
  ],
  responses: [
    'Our HIV services provide:\n- Confidential testing\n- Treatment management\n- Prevention services\n- Support groups',
    'HIV/AIDS care includes:\n- Medication management\n- Regular monitoring\n- Counseling services\nInfo: (555) 123-4713',
  ],
};