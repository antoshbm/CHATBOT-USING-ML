import { QueryCategory } from '../../types';

export const hepatitisQueries: QueryCategory = {
  keywords: [
    'hepatitis', 'hep A', 'hep B', 'hep C',
    'viral hepatitis', 'liver infection'
  ],
  responses: [
    'Hepatitis services:\n- Viral testing\n- Vaccination\n- Treatment options\n- Prevention education',
    'Our Liver Center offers:\n- Disease management\n- Antiviral therapy\n- Support services\nInfo: (555) 123-4735',
  ],
};