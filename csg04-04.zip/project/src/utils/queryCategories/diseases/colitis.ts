import { QueryCategory } from '../../types';

export const colitisQueries: QueryCategory = {
  keywords: [
    'ulcerative colitis', 'colitis', 'UC',
    'colon inflammation', 'bloody diarrhea'
  ],
  responses: [
    'Colitis symptoms include:\n- Rectal bleeding\n- Diarrhea\n- Abdominal pain\n- Urgency\nContact: (555) 123-4726',
    'Our Colitis Center offers:\n- Treatment options\n- Dietary guidance\n- Regular monitoring\n- Surgery if needed',
  ],
};