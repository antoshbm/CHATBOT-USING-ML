import { QueryCategory } from '../../types';

export const kidneyQueries: QueryCategory = {
  keywords: [
    'kidney disease', 'renal failure', 'kidney problems',
    'dialysis', 'kidney function', 'renal disease'
  ],
  responses: [
    'Kidney disease symptoms:\n- Swelling\n- Fatigue\n- Changes in urination\n- High blood pressure\nContact: (555) 123-4708',
    'Our nephrology services:\n- Kidney function tests\n- Dialysis services\n- Treatment planning\n- Dietary guidance',
  ],
};