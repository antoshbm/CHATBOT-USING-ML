import { QueryCategory } from '../../types';

export const parkinsonsQueries: QueryCategory = {
  keywords: [
    'parkinsons', 'tremors', 'parkinsons disease', 'PD',
    'movement disorder', 'shaking', 'stiffness'
  ],
  responses: [
    'Parkinson\'s symptoms include:\n- Tremors\n- Muscle stiffness\n- Balance problems\n- Slow movement\nSchedule evaluation: (555) 123-4720',
    'Our Movement Disorders Clinic offers:\n- Medication management\n- Physical therapy\n- Support groups\n- Advanced treatments',
  ],
};