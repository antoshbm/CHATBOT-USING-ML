import { QueryCategory } from '../../types';

export const thyroidQueries: QueryCategory = {
  keywords: [
    'thyroid', 'hypothyroid', 'hyperthyroid',
    'graves disease', 'thyroid nodules'
  ],
  responses: [
    'Thyroid services include:\n- Function tests\n- Medication management\n- Nodule evaluation\n- Surgery options',
    'Our Endocrine Center provides:\n- Thyroid scanning\n- Treatment plans\n- Regular monitoring\nContact: (555) 123-4730.',
  ],
};