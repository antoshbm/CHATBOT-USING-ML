import { QueryCategory } from '../../../types';

export const cardiologyQueries: QueryCategory = {
  keywords: [
    'cardiologist', 'heart doctor', 'heart specialist',
    'cardiothoracic', 'heart surgery', 'chest pain',
    'heart attack', 'cardiac', 'cardiovascular',
    'heart disease', 'arrhythmia', 'pacemaker'
  ],
  responses: [
    'Our cardiology department provides:\n- Heart disease treatment\n- Cardiac testing\n- Heart surgery\n- Preventive cardiology',
    'Cardiology services include:\n- ECG/EKG\n- Stress testing\n- Heart catheterization\n- Pacemaker management\nContact: (555) 123-4584.',
    'For chest pain or heart emergencies:\n1. Call 911 immediately\n2. Emergency cardiac care available 24/7\n3. Dedicated cardiac emergency unit',
    'Our heart specialists offer:\n- Preventive cardiology\n- Heart disease management\n- Cardiac rehabilitation\nSchedule a consultation: (555) 123-4585.',
  ],
};