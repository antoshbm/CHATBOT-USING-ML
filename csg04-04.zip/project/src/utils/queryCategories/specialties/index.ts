export * from './cardiology';
export * from './gastro';
export * from './neurology';
export * from './allergy';
export * from './dermatology';
export * from './gynecology';
export * from './ophthalmology';
export * from './specialists';

import { QueryCategory } from '../../../types';
import { cardiologyQueries } from './cardiology';
import { gastroenterologyQueries } from './gastro';
import { neurologyQueries } from './neurology';
import { allergyQueries } from './allergy';
import { dermatologyQueries } from './dermatology';
import { gynecologyQueries } from './gynecology';
import { ophthalmologyQueries } from './ophthalmology';
import { specialistQueries } from './specialists';

export const specialtyQueries: QueryCategory = {
  keywords: [
    ...cardiologyQueries.keywords,
    ...gastroenterologyQueries.keywords,
    ...neurologyQueries.keywords,
    ...allergyQueries.keywords,
    ...dermatologyQueries.keywords,
    ...gynecologyQueries.keywords,
    ...ophthalmologyQueries.keywords,
    ...specialistQueries.keywords,
    'specialist', 'specialty', 'department',
    'consultation', 'referral', 'expert'
  ],
  responses: [
    'Our hospital features multiple specialty departments. What specific type of specialist are you looking for?',
    'For specialty referrals, please contact your primary care physician or call our referral coordinator: (555) 123-4586.',
  ],
};