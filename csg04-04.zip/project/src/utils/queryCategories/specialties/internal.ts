import { QueryCategory } from '../../../types';

export const internalMedicineQueries: QueryCategory = {
  keywords: [
    'internist', 'internal medicine', 'adult medicine',
    'endocrinologist', 'diabetes', 'thyroid', 'hormones',
    'endocrine', 'metabolism', 'hormone disorder'
  ],
  responses: [
    'Our internal medicine specialists treat:\n- Diabetes\n- Thyroid disorders\n- Hormonal imbalances\n- Complex adult diseases',
    'Endocrinology services include:\n- Diabetes management\n- Thyroid disorder treatment\n- Hormone replacement therapy\nSchedule at (555) 123-4582.',
    'We offer comprehensive diabetes care including:\n- Blood sugar monitoring\n- Insulin management\n- Dietary counseling\n- Regular check-ups',
    'For thyroid disorders, we provide:\n- Diagnostic testing\n- Medication management\n- Regular monitoring\nContact our endocrinology department: (555) 123-4583.',
  ],
};