import { QueryCategory } from '../../../types';

export const dermatologyQueries: QueryCategory = {
  keywords: [
    'dermatologist', 'skin doctor', 'skin specialist',
    'acne', 'eczema', 'psoriasis', 'rash',
    'skin cancer', 'melanoma', 'mole check',
    'dermatitis', 'skin biopsy', 'botox'
  ],
  responses: [
    'Our dermatology department offers:\n- Skin cancer screening\n- Acne treatment\n- Psoriasis management\n- Cosmetic procedures',
    'Dermatology services include:\n- Skin biopsies\n- Laser treatments\n- Mole removal\n- Rash treatment\nSchedule: (555) 123-4595.',
    'We provide treatment for:\n- Chronic skin conditions\n- Hair loss\n- Nail disorders\n- Skin infections',
    'Same-day appointments available for urgent skin concerns.',
  ],
};