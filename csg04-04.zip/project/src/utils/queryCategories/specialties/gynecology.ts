import { QueryCategory } from '../../../types';

export const gynecologyQueries: QueryCategory = {
  keywords: [
    'gynecologist', 'obstetrician', 'OBGYN',
    'womens health', 'pregnancy', 'prenatal',
    'fertility', 'menopause', 'pap smear',
    'mammogram', 'birth control', 'family planning'
  ],
  responses: [
    'Our gynecology services include:\n- Annual exams\n- Pregnancy care\n- Family planning\n- Menopause management',
    'We provide comprehensive care:\n- Preventive screenings\n- Fertility services\n- Gynecologic surgery\nContact: (555) 123-4596.',
    'Obstetric services include:\n- Prenatal care\n- High-risk pregnancy\n- Delivery services\n- Postpartum care',
    'For pregnancy emergencies, our labor & delivery unit is available 24/7.',
  ],
};