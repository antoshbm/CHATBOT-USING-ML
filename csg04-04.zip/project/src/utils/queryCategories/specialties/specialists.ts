import { QueryCategory } from '../../types';

export const specialistQueries: QueryCategory = {
  keywords: [
    'specialist', 'doctor', 'physician', 'consultant',
    'find doctor', 'medical expert', 'specialist referral'
  ],
  responses: [
    'Our specialists by department:\n\n' +
    '🫀 Cardiology (Heart Disease)\n' +
    '- Dr. Sarah Chen, MD - Chief of Cardiology\n' +
    '- Dr. Michael Roberts, MD - Interventional Cardiology\n' +
    'Contact: (555) 123-4800\n\n' +
    '🩺 Endocrinology (Diabetes)\n' +
    '- Dr. James Wilson, MD - Diabetes Specialist\n' +
    '- Dr. Emily Patel, MD - Metabolic Disorders\n' +
    'Contact: (555) 123-4801\n\n' +
    '🔬 Oncology (Cancer)\n' +
    '- Dr. David Thompson, MD - Chief Oncologist\n' +
    '- Dr. Lisa Anderson, MD - Radiation Oncology\n' +
    'Contact: (555) 123-4802\n\n' +
    '🧠 Neurology (Stroke)\n' +
    '- Dr. Robert Kim, MD - Stroke Specialist\n' +
    '- Dr. Maria Garcia, MD - Neuro-interventionist\n' +
    'Contact: (555) 123-4803\n\n' +
    '🫁 Pulmonology (Respiratory)\n' +
    '- Dr. Thomas Brown, MD - Chief Pulmonologist\n' +
    '- Dr. Rachel White, MD - Respiratory Care\n' +
    'Contact: (555) 123-4804\n\n' +
    '🦴 Rheumatology (Arthritis)\n' +
    '- Dr. Jennifer Lee, MD - Arthritis Specialist\n' +
    '- Dr. William Scott, MD - Joint Care\n' +
    'Contact: (555) 123-4805\n\n' +
    '💊 Internal Medicine (Hypertension)\n' +
    '- Dr. Daniel Martinez, MD - Hypertension Specialist\n' +
    '- Dr. Susan Taylor, MD - Cardiovascular Prevention\n' +
    'Contact: (555) 123-4806\n\n' +
    '🧩 Neurology (Alzheimer\'s)\n' +
    '- Dr. Patricia Moore, MD - Memory Disorders\n' +
    '- Dr. Richard Johnson, MD - Cognitive Care\n' +
    'Contact: (555) 123-4807\n\n' +
    '🫘 Nephrology (Kidney)\n' +
    '- Dr. Kevin Chang, MD - Chief Nephrologist\n' +
    '- Dr. Amanda Wright, MD - Dialysis Specialist\n' +
    'Contact: (555) 123-4808\n\n' +
    '🫓 Hepatology (Liver)\n' +
    '- Dr. Christopher Lee, MD - Liver Specialist\n' +
    '- Dr. Michelle Park, MD - Hepatic Disorders\n' +
    'Contact: (555) 123-4809\n\n' +
    '🧠 Psychiatry (Mental Health)\n' +
    '- Dr. Elizabeth Ross, MD - Chief Psychiatrist\n' +
    '- Dr. Andrew Collins, MD - Clinical Psychology\n' +
    'Contact: (555) 123-4810\n\n' +
    '⚖️ Bariatric Medicine (Obesity)\n' +
    '- Dr. Nicole Adams, MD - Weight Management\n' +
    '- Dr. Steven Hughes, MD - Bariatric Surgery\n' +
    'Contact: (555) 123-4811\n\n' +
    '🔬 Infectious Disease (HIV/AIDS)\n' +
    '- Dr. Mark Davidson, MD - HIV Specialist\n' +
    '- Dr. Laura Bennett, MD - Infectious Disease\n' +
    'Contact: (555) 123-4812\n\n' +
    '🫁 Pulmonary Medicine (Breathing)\n' +
    '- Dr. Gregory Peters, MD - Respiratory Specialist\n' +
    '- Dr. Sarah Mitchell, MD - Pulmonary Care\n' +
    'Contact: (555) 123-4813\n\n' +
    '🦠 Infectious Disease\n' +
    '- Dr. Victoria Chen, MD - Chief of Infectious Disease\n' +
    '- Dr. Jonathan Taylor, MD - Epidemiology\n' +
    'Contact: (555) 123-4814\n\n' +
    '💉 Immunology\n' +
    '- Dr. Rebecca Wong, MD - Chief Immunologist\n' +
    '- Dr. Brian Miller, MD - Vaccine Specialist\n' +
    'Contact: (555) 123-4815\n\n' +
    'For appointments, call our central scheduling: (555) 123-4816\n' +
    'Emergency? Call 911 or visit our 24/7 Emergency Department',
  ],
};