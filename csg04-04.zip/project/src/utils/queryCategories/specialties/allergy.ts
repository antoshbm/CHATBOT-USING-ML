import { QueryCategory } from '../../../types';

export const allergyQueries: QueryCategory = {
  keywords: [
    'allergist', 'immunologist', 'allergy', 'allergies',
    'asthma', 'food allergy', 'hay fever', 'hives',
    'immune system', 'immunotherapy', 'allergy shots',
    'sinus', 'rhinitis', 'eczema'
  ],
  responses: [
    'Our allergy specialists provide:\n- Allergy testing\n- Immunotherapy\n- Asthma treatment\n- Food allergy management',
    'Allergy services include:\n- Skin testing\n- Blood tests\n- Allergy shots\n- Treatment plans\nContact: (555) 123-4594.',
    'We offer comprehensive testing for:\n- Environmental allergies\n- Food allergies\n- Drug allergies\n- Seasonal allergies',
    'For severe allergic reactions, seek immediate emergency care.',
  ],
};