import { QueryCategory } from '../../../types';

export const gastroenterologyQueries: QueryCategory = {
  keywords: [
    'gastroenterologist', 'GI doctor', 'digestive', 'stomach',
    'hepatologist', 'liver', 'intestine', 'colon',
    'IBS', 'ulcer', 'acid reflux', 'GERD', 'endoscopy'
  ],
  responses: [
    'Gastroenterology services:\n- Digestive disorders\n- Liver disease\n- Endoscopy procedures\nContact: (555) 123-4591.',
    'Our GI clinic offers:\n- Colonoscopy\n- Upper endoscopy\n- Liver disease treatment\n- IBS management',
    'For digestive concerns, we provide:\n- Diagnostic testing\n- Nutritional counseling\n- Treatment plans\nSchedule: (555) 123-4592.',
    'Emergency GI services available 24/7 for severe abdominal pain or bleeding.',
  ],
};