import { QueryCategory } from '../../../types';

export const orthopedicsQueries: QueryCategory = {
  keywords: [
    'orthopedic', 'bone doctor', 'joint', 'fracture',
    'arthritis', 'rheumatologist', 'lupus', 'autoimmune',
    'sports injury', 'knee', 'hip', 'shoulder', 'spine'
  ],
  responses: [
    'Our orthopedic services include:\n- Joint replacement\n- Fracture care\n- Sports medicine\n- Spine surgery\nSchedule at (555) 123-4589.',
    'Rheumatology department treats:\n- Rheumatoid arthritis\n- Lupus\n- Autoimmune conditions\nContact: (555) 123-4590.',
    'Sports medicine services:\n- Injury assessment\n- Physical therapy\n- Rehabilitation\n- Performance optimization',
    'For acute injuries or fractures:\n1. Visit emergency department\n2. On-call orthopedic surgeon available\n3. Same-day appointments for urgent cases',
  ],
};