import { QueryCategory } from '../../../types';

export const ophthalmologyQueries: QueryCategory = {
  keywords: [
    'ophthalmologist', 'eye doctor', 'optometrist',
    'vision', 'eyesight', 'glasses', 'contacts',
    'cataracts', 'glaucoma', 'retina',
    'eye surgery', 'LASIK', 'eye exam'
  ],
  responses: [
    'Our eye care services include:\n- Comprehensive eye exams\n- Vision correction\n- Eye surgery\n- Emergency eye care',
    'Ophthalmology treatments:\n- Cataract surgery\n- Glaucoma management\n- LASIK\n- Retinal care\nSchedule: (555) 123-4597.',
    'We provide care for:\n- Vision problems\n- Eye diseases\n- Eye injuries\n- Pediatric eye care',
    'For eye emergencies, our eye care center is available 24/7.',
  ],
};