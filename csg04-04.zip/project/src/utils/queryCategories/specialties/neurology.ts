import { QueryCategory } from '../../../types';

export const neurologyQueries: QueryCategory = {
  keywords: [
    'neurologist', 'brain doctor', 'neurosurgeon',
    'epilepsy', 'seizure', 'migraine', 'multiple sclerosis',
    'brain tumor', 'spine', 'nerve', 'stroke',
    'parkinsons', 'alzheimers', 'memory loss'
  ],
  responses: [
    'Our neurology department treats:\n- Epilepsy\n- Migraines\n- Multiple sclerosis\n- Stroke care\nContact: (555) 123-4587.',
    'Neurology services include:\n- EEG testing\n- Memory disorders\n- Movement disorders\n- Nerve conditions',
    'For stroke symptoms:\n1. Call 911 immediately\n2. Note when symptoms started\n3. Our stroke unit is available 24/7',
    'Schedule a neurology consultation: (555) 123-4588.',
  ],
};