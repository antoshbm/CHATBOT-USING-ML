import { QueryCategory } from '../../../types';

export const primaryCareQueries: QueryCategory = {
  keywords: [
    'general practitioner', 'GP', 'family doctor', 'family physician',
    'primary care', 'regular doctor', 'family medicine',
    'general medicine', 'routine checkup', 'annual physical'
  ],
  responses: [
    'Our primary care physicians provide:\n- Routine check-ups\n- Preventive care\n- Health screenings\n- Chronic disease management\nCall (555) 123-4580 to schedule.',
    'Our family medicine department includes experienced physicians who can care for your entire family, from newborns to elderly.',
    'Primary care services include:\n- Vaccinations\n- Health assessments\n- Chronic disease management\n- Referrals to specialists',
    'Same-day appointments often available for urgent issues. Contact our primary care desk: (555) 123-4581.',
  ],
};