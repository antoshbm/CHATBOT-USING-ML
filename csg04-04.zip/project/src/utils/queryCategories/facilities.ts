import { QueryCategory } from '../../types';

export const facilityQueries: QueryCategory = {
  keywords: [
    'facility', 'amenities', 'cafeteria', 'food court',
    'wheelchair', 'elevator', 'restroom', 'bathroom',
    'chapel', 'gift shop', 'ATM', 'wifi',
    'waiting area', 'information desk'
  ],
  responses: [
    'Our facilities include:\n- 24/7 Cafeteria (2nd Floor)\n- Gift Shop (Main Lobby)\n- Chapel (1st Floor)\n- Free WiFi throughout',
    'Wheelchair assistance is available at all main entrances - ask any staff member or call (555) 123-4574.',
    'All floors have accessible restrooms and water fountains. Family restrooms are available on floors 1, 3, and 5.',
    'Additional amenities:\n- ATMs in main lobby\n- Mobile charging stations\n- Quiet rooms\n- Family waiting areas',
  ],
};