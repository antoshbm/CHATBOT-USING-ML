import { QueryCategory } from '../../types';

export const ambulanceQueries: QueryCategory = {
  keywords: [
    'ambulance', 'emergency vehicle', 'paramedic',
    'emergency transport', 'medical transport',
    'emergency ride', '911', 'emergency service',
    'urgent transport', 'patient transport'
  ],
  responses: [
    'For emergency ambulance services, please call 911 or our dedicated ambulance hotline: (555) 911-0005.',
    'Our ambulance services are available 24/7 with GPS-tracked vehicles and trained paramedics.',
    'Non-emergency medical transport can be scheduled in advance by calling (555) 123-4572.',
    'Our ambulances are equipped with advanced life support systems and staffed by certified emergency medical technicians.',
    'For inter-hospital transfers, please have the referring physician contact our transfer center.',
    'We provide specialized neonatal and pediatric transport services. Call (555) 911-0006 for immediate assistance.',
  ],
};