import { QueryCategory } from '../../types';

export const skinCareQueries: QueryCategory = {
  keywords: [
    'skin care', 'skincare', 'skin health', 'skin routine',
    'skin treatment', 'skin consultation', 'skin advice',
    'skin products', 'skin concerns', 'skin assessment'
  ],
  responses: [
    'Our skin care services include:\n- Skin health assessments\n- Personalized care plans\n- Product recommendations\n- Treatment consultations\nSchedule: (555) 123-4660',
    
    'Common skin concerns we treat:\n- Acne\n- Aging signs\n- Sun damage\n- Pigmentation\n- Dry/oily skin\n- Sensitive skin',
    
    'Skin care consultations include:\n- Skin type analysis\n- Concern evaluation\n- Treatment planning\n- Product guidance\nBook now: (555) 123-4661',
    
    'Prevention services:\n- Sun protection advice\n- Skin cancer screening\n- Anti-aging strategies\n- Lifestyle recommendations',
  ],
};