import { QueryCategory } from '../../types';

export const dermatologySpecialistsQueries: QueryCategory = {
  keywords: [
    'dermatologist', 'skin specialist', 'skin doctor',
    'cosmetic surgeon', 'dermatology expert', 'skin surgeon',
    'aesthetic doctor', 'dermatology specialist'
  ],
  responses: [
    'Our dermatology team:\n\n' +
    '🔬 Medical Dermatology\n' +
    '- Dr. Jessica Kim, MD - Chief of Dermatology\n' +
    '  Specializes in complex skin conditions\n' +
    '  Contact: (555) 123-4666\n\n' +
    '✨ Cosmetic Dermatology\n' +
    '- Dr. Michael Chen, MD - Aesthetic Director\n' +
    '  Expert in anti-aging treatments\n' +
    '  Contact: (555) 123-4667\n\n' +
    '🔍 Skin Cancer Specialists\n' +
    '- Dr. Sarah Thompson, MD - Mohs Surgeon\n' +
    '  Skin cancer detection and treatment\n' +
    '  Contact: (555) 123-4668\n\n' +
    '🧬 Pediatric Dermatology\n' +
    '- Dr. Robert Martinez, MD - Pediatric Lead\n' +
    '  Children\'s skin conditions\n' +
    '  Contact: (555) 123-4669\n\n' +
    'Emergency skin concerns: Contact our 24/7 dermatology line: (555) 123-4670',
    
    'All our dermatologists are board-certified with extensive experience in their specialties.',
    
    'Same-day appointments available for urgent skin conditions.',
    
    'Virtual consultations available with all specialists.',
  ],
};