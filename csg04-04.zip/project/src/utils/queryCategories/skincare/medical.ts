import { QueryCategory } from '../../types';

export const medicalDermatologyQueries: QueryCategory = {
  keywords: [
    'medical dermatology', 'skin condition', 'skin disease',
    'dermatitis', 'skin infection', 'skin disorder',
    'rash treatment', 'skin problem', 'skin diagnosis'
  ],
  responses: [
    'Medical dermatology services:\n- Skin disease treatment\n- Infection management\n- Autoimmune conditions\n- Skin cancer care\nUrgent care: (555) 123-4664',
    
    'We treat conditions like:\n- Eczema/Psoriasis\n- Skin infections\n- Autoimmune disorders\n- Skin cancers\n- Chronic conditions',
    
    'Treatment approaches:\n- Topical medications\n- Oral medications\n- Light therapy\n- Surgical options\nInfo: (555) 123-4665',
    
    'Diagnostic services:\n- Skin biopsies\n- Allergy testing\n- Imaging studies\n- Lab analysis',
  ],
};