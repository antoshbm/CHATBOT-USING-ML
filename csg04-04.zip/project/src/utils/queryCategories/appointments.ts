import { QueryCategory } from '../../types';

export const appointmentQueries: QueryCategory = {
  keywords: ['appointment', 'book', 'schedule', 'visit', 'doctor', 'consultation', 'checkup'],
  responses: [
    'You can book an appointment through our online portal or by calling our reception at (555) 123-4567.',
    'Please provide your preferred date, time, and doctor\'s specialization for the appointment.',
    'For specialist consultations, please have your referral ready when booking.',
    'We offer both in-person and telehealth appointments. Which would you prefer?',
  ],
};