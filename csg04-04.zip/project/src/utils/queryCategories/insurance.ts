import { QueryCategory } from '../../types';

export const insuranceQueries: QueryCategory = {
  keywords: [
    'insurance', 'coverage', 'policy', 'insurer',
    'network', 'in-network', 'out-of-network',
    'preauthorization', 'pre-approval', 'benefits',
    'insurance card', 'insurance provider'
  ],
  responses: [
    'We accept major insurance plans including:\n- Blue Cross Blue Shield\n- Aetna\n- UnitedHealthcare\n- Cigna\n- Medicare/Medicaid\n- State Health Insurance',
    'For insurance verification, please provide:\n1. Insurance card\n2. Photo ID\n3. Current policy information\nContact our insurance desk: (555) 123-4575',
    'Pre-authorization is required for:\n- Scheduled surgeries\n- Advanced imaging (MRI, CT)\n- Specialty treatments\nOur insurance team can assist with the process.',
    'For international insurance plans, please contact our International Patient Services at (555) 123-4576.',
    'We offer insurance counseling to help understand your benefits and coverage. Schedule a free consultation at (555) 123-4577.',
  ],
};