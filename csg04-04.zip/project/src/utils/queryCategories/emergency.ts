import { QueryCategory } from '../../types';

export const emergencyQueries: QueryCategory = {
  keywords: ['emergency', 'urgent', 'immediate', 'critical', 'ambulance', 'severe', 'life-threatening'],
  responses: [
    'For medical emergencies, please call 911 immediately.',
    'Our emergency department is open 24/7. Please proceed to the emergency entrance.',
    'If you need immediate medical attention but can travel safely, our urgent care center is located at the ground floor.',
    'For chest pain, severe bleeding, or difficulty breathing, call emergency services immediately.',
  ],
};