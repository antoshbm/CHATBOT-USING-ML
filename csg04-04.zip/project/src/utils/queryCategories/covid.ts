import { QueryCategory } from '../../types';

export const covidQueries: QueryCategory = {
  keywords: ['covid', 'coronavirus', 'vaccine', 'vaccination', 'booster', 'test', 'testing', 'mask'],
  responses: [
    'COVID-19 testing is available daily from 8 AM to 4 PM. Appointments are required.',
    'We offer COVID-19 vaccinations and boosters. Please schedule through our portal.',
    'Masks are required in all clinical areas of the hospital.',
    'If you have COVID-19 symptoms, please call before visiting the hospital.',
  ],
};