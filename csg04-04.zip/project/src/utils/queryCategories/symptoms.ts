import { QueryCategory } from '../../types';

export const symptomQueries: QueryCategory = {
  keywords: [
    'symptom', 'pain', 'fever', 'cough',
    'headache', 'nausea', 'dizziness', 'fatigue',
    'breathing', 'chest pain', 'blood pressure',
    'diabetes', 'heart', 'stomach'
  ],
  responses: [
    'If you\'re experiencing severe symptoms like chest pain or difficulty breathing, please seek immediate medical attention.',
    'Our symptom checker can help you understand potential causes. However, for accurate diagnosis, please consult with a doctor.',
    'We offer same-day appointments for urgent symptoms. Would you like to schedule one?',
    'Certain symptoms may require emergency care. Please describe your symptoms for appropriate guidance.',
    'Our nurses can provide initial symptom assessment over the phone: (555) 123-4570',
    'For chronic symptoms, we recommend scheduling a comprehensive evaluation with our specialists.',
  ],
};