import { QueryCategory } from '../../types';

export const visitingQueries: QueryCategory = {
  keywords: ['visiting', 'visitors', 'guest', 'family', 'hours', 'visit'],
  responses: [
    'General visiting hours are from 10 AM to 8 PM daily.',
    'ICU visiting hours are restricted to immediate family only, 2 PM to 6 PM.',
    'All visitors must check in at the front desk for a visitor\'s pass.',
    'Children under 12 must be accompanied by an adult.',
  ],
};