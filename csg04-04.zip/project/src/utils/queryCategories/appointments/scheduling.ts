import { QueryCategory } from '../../types';

export const appointmentSchedulingQueries: QueryCategory = {
  keywords: [
    'schedule appointment', 'book appointment', 'make appointment',
    'appointment available', 'appointment slot', 'appointment time',
    'next available', 'schedule visit', 'book consultation'
  ],
  responses: [
    'Yes, we can schedule an appointment for you. Please provide:\n- Preferred date/time\n- Type of visit\n- Insurance information\nCall (555) 123-4567 to schedule.',
    'No appointments available today. Next available slots:\n- Regular visits: Tomorrow\n- Specialist visits: 3-5 days\n- Non-urgent care: 1-2 weeks\nCall (555) 123-4567 to schedule.',
    'Same-day appointments available for urgent cases only.\nRegular appointments available starting tomorrow.\nCall (555) 123-4567 to schedule.',
    'Virtual appointments available within 24 hours.\nIn-person visits available next week.\nCall (555) 123-4567 to schedule.',
  ],
};