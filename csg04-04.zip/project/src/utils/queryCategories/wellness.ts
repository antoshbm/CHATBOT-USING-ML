import { QueryCategory } from '../../types';

export const wellnessQueries: QueryCategory = {
  keywords: [
    'wellness', 'prevention', 'lifestyle', 'health tips',
    'nutrition', 'exercise', 'stress', 'mental health',
    'healthy living', 'diet', 'fitness', 'meditation',
    'sleep', 'weight management'
  ],
  responses: [
    'Our wellness center offers programs for stress management, nutrition counseling, and fitness guidance.',
    'We provide personalized wellness plans that include diet, exercise, and lifestyle recommendations.',
    'Join our weekly wellness workshops covering topics like nutrition, stress management, and healthy living.',
    'Our mental health professionals can help you develop strategies for better emotional well-being.',
    'We offer health coaching services to help you achieve your wellness goals.',
    'Regular wellness check-ups can help maintain your overall health. Would you like to schedule one?',
  ],
};