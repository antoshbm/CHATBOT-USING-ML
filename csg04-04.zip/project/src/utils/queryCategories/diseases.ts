import { QueryCategory } from '../../types';

export const diseaseQueries: QueryCategory = {
  keywords: [
    'disease', 'condition', 'symptoms', 'treatment',
    'diagnosis', 'chronic', 'acute', 'infection',
    'illness', 'disease management', 'prevention',
    'risk factors', 'complications'
  ],
  responses: [
    'Our hospital specializes in treating various acute and chronic conditions. Please describe your symptoms for specific guidance.',
    'We offer comprehensive disease management programs for conditions like diabetes, heart disease, and respiratory disorders.',
    'For accurate diagnosis, please schedule an appointment with our specialists. They can provide detailed evaluation and treatment plans.',
    'We provide patient education resources about disease prevention and management. Would you like access to these materials?',
    'Our team offers support groups for patients managing chronic conditions. Would you like information about joining?',
    'Regular health screenings can help detect diseases early. Would you like to schedule a check-up?',
  ],
};