import { QueryCategory } from '../../types';

export const billingQueries: QueryCategory = {
  keywords: [
    'bill', 'payment', 'insurance', 'cost', 'charge', 'fee',
    'financial', 'coverage', 'claim', 'cashless', 'refund',
    'estimate', 'price', 'rates', 'copay', 'deductible',
    'reimbursement', 'health check-up cost'
  ],
  responses: [
    'For billing inquiries, please contact our billing department at (555) 123-4568.',
    'We accept most major insurance plans including:\n- Blue Cross Blue Shield\n- Aetna\n- UnitedHealthcare\n- Medicare/Medicaid\nPlease verify coverage with your provider.',
    'General health check-up costs range from $150-$500 depending on tests included. We can provide a detailed estimate after understanding your specific needs.',
    'To request a refund:\n1. Fill out the refund form (available at billing desk or online)\n2. Attach supporting documents\n3. Submit to billing department\nProcessing time: 7-10 business days.',
    'For cashless claims:\n1. Present insurance card at admission\n2. We\'ll verify coverage with your provider\n3. You\'ll only pay applicable deductibles/copays\nContact our insurance desk: (555) 123-4575.',
    'To understand your hospital charges:\n1. Log into the patient portal for itemized bills\n2. Schedule a consultation with our billing counselor\n3. Call billing support for line-by-line explanation',
  ],
};