import { QueryCategory } from '../../types';

export const doctorQueries: QueryCategory = {
  keywords: [
    'doctor', 'physician', 'surgeon', 'specialist', 'consultant',
    'experience', 'qualification', 'expertise', 'background',
    'available doctors', 'find doctor', 'doctor profile'
  ],
  responses: [
    'Our hospital has over 50 experienced doctors across various specialties. You can view their profiles on our website.',
    'All our doctors are board-certified with extensive experience in their respective fields.',
    'To find a specific doctor, you can search by specialty, name, or availability in our directory.',
    'Our doctors offer both in-person and telehealth consultations. Would you like to schedule an appointment?',
    'Each doctor\'s profile includes their qualifications, experience, and patient reviews.',
    'We have specialists available 24/7 for emergency consultations.',
  ],
};