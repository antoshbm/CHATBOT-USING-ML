import { QueryCategory } from '../types';

export const timingQueries: QueryCategory = {
  keywords: [
    'timing', 'hours', 'schedule', 'open hours',
    'working hours', 'visiting hours', 'operation time',
    'department timing', 'clinic hours', 'availability',
    'when open', 'closing time', 'business hours'
  ],
  responses: [
    'Hospital departments operate on different schedules:\n- Emergency: 24/7\n- Outpatient: Mon-Fri 8 AM - 6 PM\n- Pharmacy: Mon-Sat 8 AM - 8 PM\n- Lab: 24/7',
    'Visiting hours:\n- General wards: 10 AM - 8 PM\n- ICU: 2 PM - 6 PM\n- Pediatrics: 9 AM - 9 PM\n- Maternity: 24/7 for partners',
    'Specialty clinics (Mon-Fri):\n- Morning: 9 AM - 1 PM\n- Evening: 4 PM - 8 PM\nContact specific department for appointments.',
    'Administrative offices:\n- Mon-Fri: 9 AM - 5 PM\n- Billing: 8:30 AM - 4:30 PM\n- Medical Records: 9 AM - 4 PM',
  ],
};