import { QueryCategory } from '../types';

export const telemedicineQueries: QueryCategory = {
  keywords: [
    'telemedicine', 'virtual visit', 'video consultation',
    'online doctor', 'remote healthcare', 'virtual care',
    'telehealth', 'video appointment', 'virtual consultation',
    'remote doctor', 'online medical', 'digital health'
  ],
  responses: [
    'Virtual care services available:\n- Video consultations\n- Prescription renewals\n- Follow-up visits\n- Mental health support\nSchedule now: (555) 123-4650',
    
    'Telemedicine benefits:\n- No travel required\n- Reduced wait times\n- Same-day appointments\n- Secure platform\nTechnical support: (555) 123-4651',
    
    'Virtual visits suitable for:\n- Minor illnesses\n- Medication reviews\n- Lab result discussions\n- Mental health sessions\n- Chronic condition monitoring',
    
    'Before your virtual visit:\n1. Test your device\n2. Find a quiet space\n3. Have your medical history ready\n4. List your symptoms/questions\nHelp line: (555) 123-4652',
    
    'Not suitable for telemedicine:\n- Severe chest pain\n- Difficulty breathing\n- Major injuries\n- Medical emergencies\nFor emergencies call 911',
    
    'Technical requirements:\n- Stable internet\n- Camera-enabled device\n- Updated browser\n- Private location\nSetup help: (555) 123-4653',
  ],
};