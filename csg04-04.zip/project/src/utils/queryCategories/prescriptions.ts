import { QueryCategory } from '../../types';

export const prescriptionQueries: QueryCategory = {
  keywords: ['prescription', 'medicine', 'refill', 'pharmacy', 'medication', 'drug'],
  responses: [
    'For prescription refills, please contact our pharmacy at (555) 123-4569.',
    'You can request prescription refills through our patient portal.',
    'Our in-house pharmacy is open Monday to Saturday, 8 AM to 8 PM.',
    'Please allow 48 hours for prescription refill requests to be processed.',
  ],
};