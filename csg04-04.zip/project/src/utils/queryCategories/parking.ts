import { QueryCategory } from '../../types';

export const parkingQueries: QueryCategory = {
  keywords: [
    'parking', 'park', 'valet', 'garage', 'lot',
    'car park', 'parking space', 'parking spot',
    'handicap parking', 'disabled parking',
    'visitor parking', 'staff parking',
    'emergency parking', 'parking validation'
  ],
  responses: [
    'Our hospital offers multiple parking options:\n- Main Garage (24/7)\n- Visitor Lot (6 AM - 10 PM)\n- Emergency Parking (Always Available)\n- Valet Service (7 AM - 8 PM)',
    'Parking rates:\n- First hour: Free\n- 1-3 hours: $5\n- 3-6 hours: $8\n- Daily maximum: $15\nValidation available for patients.',
    'Handicap parking spaces are available near all main entrances. Please display your permit.',
    'Valet parking is available at the main entrance for $10, with validation options for patients.',
    'Free parking is available for emergency department visitors in the designated ED lot.',
    'Monthly parking passes are available for frequent visitors. Contact parking services at (555) 123-4573.',
  ],
};