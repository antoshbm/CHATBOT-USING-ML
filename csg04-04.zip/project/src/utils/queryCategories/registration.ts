import { QueryCategory } from '../../types';

export const registrationQueries: QueryCategory = {
  keywords: [
    'register', 'registration', 'sign up', 'new patient',
    'enrollment', 'admission', 'patient registration',
    'join', 'onboarding', 'intake', 'first visit',
    'patient form', 'registration process'
  ],
  responses: [
    'New patient registration can be completed online through our patient portal or in person at the registration desk.',
    'Required documents for registration:\n- Valid ID\n- Insurance card\n- Emergency contact information\n- Medical history',
    'Our registration desk is open Monday to Friday, 8 AM to 6 PM. For your convenience, you can start the registration process online.',
    'To expedite your first visit, please complete our pre-registration form available on our website.',
    'Same-day registration is available for urgent care. Please arrive 30 minutes before your appointment.',
    'For international patients, please contact our International Patient Services at (555) 123-4571.',
  ],
};