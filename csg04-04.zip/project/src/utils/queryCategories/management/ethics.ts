import { QueryCategory } from '../../types';

export const medicalEthicsQueries: QueryCategory = {
  keywords: [
    'medical ethics', 'ethical care', 'healthcare ethics',
    'ethical guidelines', 'ethical standards', 'patient ethics',
    'clinical ethics', 'ethical practice'
  ],
  responses: [
    'Ethical principles include:\n- Patient autonomy\n- Informed consent\n- Confidentiality\n- Fair treatment',
    'Ethics consultation for:\n- Complex decisions\n- Treatment conflicts\n- End-of-life care\n- Resource allocation',
    'Ethics committee contact: (555) 123-4647.',
    'Confidential consultation available.',
  ],
};