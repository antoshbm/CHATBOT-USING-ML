import { QueryCategory } from '../../types';

export const symptomAnalysisQueries: QueryCategory = {
  keywords: [
    'symptom analysis', 'clinical assessment', 'diagnosis process',
    'medical evaluation', 'symptom check', 'health assessment',
    'clinical evaluation', 'medical diagnosis'
  ],
  responses: [
    'Assessment process includes:\n- Symptom history\n- Physical examination\n- Diagnostic tests\n- Specialist consultation',
    'Evaluation tools:\n- Lab testing\n- Imaging studies\n- Clinical observation\n- Patient history',
    'For urgent assessment: (555) 123-4645.',
    'Comprehensive evaluations available.',
  ],
};