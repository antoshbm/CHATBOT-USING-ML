import { QueryCategory } from '../../types';

export const qualityControlQueries: QueryCategory = {
  keywords: [
    'quality', 'standards', 'certification', 'accreditation',
    'patient safety', 'medical errors', 'quality assurance',
    'improvement', 'patient feedback', 'satisfaction'
  ],
  responses: [
    'Our hospital maintains:\n- Joint Commission accreditation\n- Quality assurance programs\n- Patient safety initiatives\n- Regular audits',
    'Quality measures include:\n- Patient satisfaction surveys\n- Outcome tracking\n- Safety protocols\n- Performance metrics',
    'We welcome patient feedback through:\n- Online surveys\n- Feedback forms\n- Patient advocacy office',
    'For quality-related concerns, contact our patient advocate: (555) 123-4601.',
  ],
};