import { QueryCategory } from '../../types';

export const financeQueries: QueryCategory = {
  keywords: [
    'financial management', 'budget', 'accounting',
    'cost control', 'revenue', 'expenses',
    'financial planning', 'hospital finances'
  ],
  responses: [
    'Financial services include:\n- Budget management\n- Cost analysis\n- Revenue tracking\n- Expense control',
    'Regular financial audits conducted.',
    'Budget reviews quarterly.',
    'Finance department: (555) 123-4638.',
  ],
};