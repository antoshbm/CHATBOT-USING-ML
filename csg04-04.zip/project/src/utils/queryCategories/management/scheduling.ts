import { QueryCategory } from '../../types';

export const schedulingQueries: QueryCategory = {
  keywords: [
    'staff scheduling', 'shift management', 'rotation',
    'duty roster', 'work hours', 'shift changes',
    'schedule conflicts', 'on-call schedule'
  ],
  responses: [
    'Scheduling system manages:\n- Staff shifts\n- On-call rotations\n- Department coverage\n- Emergency backup',
    'Shift schedules posted two weeks in advance.',
    'Schedule changes must be approved by department heads.',
    'Scheduling office: (555) 123-4634.',
  ],
};