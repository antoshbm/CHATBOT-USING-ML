import { QueryCategory } from '../../types';

export const itManagementQueries: QueryCategory = {
  keywords: [
    'IT systems', 'computer systems', 'technical support',
    'system maintenance', 'software updates', 'network',
    'EMR system', 'technology issues', 'digital security'
  ],
  responses: [
    'IT support available for:\n- Clinical systems\n- Administrative software\n- Network issues\n- Security concerns',
    '24/7 technical support for critical systems.',
    'Regular system maintenance and updates.',
    'IT helpdesk: (555) 123-4637.',
  ],
};