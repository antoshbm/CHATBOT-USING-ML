import { QueryCategory } from '../../types';

export const healthEducationQueries: QueryCategory = {
  keywords: [
    'health education', 'patient teaching', 'medical information',
    'health literacy', 'patient education', 'health knowledge',
    'self-care education', 'disease education'
  ],
  responses: [
    'Education resources include:\n- Disease information\n- Treatment guides\n- Self-care instructions\n- Prevention tips',
    'Available formats:\n- Written materials\n- Video resources\n- Group classes\n- One-on-one teaching',
    'For educational materials: (555) 123-4643.',
    'Multilingual resources available.',
  ],
};