import { QueryCategory } from '../../types';

export const trainingQueries: QueryCategory = {
  keywords: [
    'staff training', 'professional development',
    'medical education', 'skill development',
    'certification', 'continuing education',
    'workshops', 'training programs'
  ],
  responses: [
    'Training programs include:\n- Medical procedures\n- Emergency response\n- Technology systems\n- Patient care',
    'Regular skill updates required for all staff.',
    'Continuing education programs available.',
    'Training inquiries: Contact HR at (555) 123-4633.',
  ],
};