import { QueryCategory } from '../../types';

export const handoverQueries: QueryCategory = {
  keywords: [
    'shift handover', 'handoff', 'shift change',
    'patient transfer', 'care transition', 'shift report',
    'patient handoff', 'clinical handover'
  ],
  responses: [
    'Shift handover protocols include:\n- Patient status updates\n- Medication schedules\n- Care plans\n- Critical alerts',
    'Handover documentation required:\n- Patient condition\n- Recent changes\n- Pending tests\n- Care instructions',
    'For urgent handover issues: Contact charge nurse at (555) 123-4640.',
    'Structured handover ensures continuity of care.',
  ],
};