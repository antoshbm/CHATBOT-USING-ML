import { QueryCategory } from '../../types';

export const emergencyManagementQueries: QueryCategory = {
  keywords: [
    'emergency protocol', 'disaster plan', 'crisis management',
    'emergency response', 'evacuation plan', 'code blue',
    'rapid response', 'emergency preparedness', 'mass casualty'
  ],
  responses: [
    'Emergency protocols include:\n- Code system\n- Evacuation procedures\n- Disaster response\n- Mass casualty plan',
    'Emergency response teams available 24/7.',
    'Regular emergency drills conducted for staff preparedness.',
    'For emergency protocols: Contact security at (555) 123-4631.',
  ],
};