import { QueryCategory } from '../../types';

export const complianceQueries: QueryCategory = {
  keywords: [
    'compliance', 'regulations', 'legal requirements',
    'healthcare laws', 'policy', 'guidelines',
    'protocols', 'standards', 'regulatory', 'HIPAA compliance'
  ],
  responses: [
    'We maintain compliance with:\n- Healthcare regulations\n- Safety standards\n- Privacy laws\n- Industry guidelines',
    'Regular compliance audits conducted.',
    'Staff training on compliance requirements.',
    'Compliance concerns: Contact officer at (555) 123-4632.',
  ],
};