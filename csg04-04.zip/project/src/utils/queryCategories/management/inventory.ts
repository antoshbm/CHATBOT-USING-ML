import { QueryCategory } from '../../types';

export const inventoryQueries: QueryCategory = {
  keywords: [
    'inventory', 'supplies', 'stock', 'medical supplies',
    'pharmacy stock', 'supply chain', 'ordering',
    'stock management', 'inventory control', 'supplies tracking'
  ],
  responses: [
    'Our inventory management system tracks:\n- Medical supplies\n- Medications\n- Equipment\n- PPE supplies',
    'Supply requests can be made through:\n- Department heads\n- Online requisition system\n- Emergency supply hotline',
    'For urgent supply needs: (555) 123-4630.',
    'Inventory levels are monitored 24/7 with automated reordering.',
  ],
};