import { QueryCategory } from '../../types';

export const maintenanceQueries: QueryCategory = {
  keywords: [
    'maintenance', 'repairs', 'facility upkeep',
    'equipment maintenance', 'building maintenance',
    'preventive maintenance', 'service requests'
  ],
  responses: [
    'Maintenance services include:\n- Equipment repairs\n- Facility upkeep\n- Preventive maintenance\n- Emergency repairs',
    'Regular maintenance schedules for all equipment.',
    'Priority response for critical systems.',
    'Maintenance requests: (555) 123-4635.',
  ],
};