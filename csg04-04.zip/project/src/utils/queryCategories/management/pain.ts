import { QueryCategory } from '../../types';

export const painAssessmentQueries: QueryCategory = {
  keywords: [
    'pain assessment', 'pain scale', 'pain management',
    'pain control', 'pain evaluation', 'pain relief',
    'chronic pain', 'acute pain', 'pain medication'
  ],
  responses: [
    'Pain assessment tools:\n- Numeric rating scale\n- Visual analog scale\n- Face scale\n- Behavioral assessment',
    'Pain management options:\n- Medication therapy\n- Physical therapy\n- Alternative methods\n- Pain specialists',
    'For pain management consultation: (555) 123-4642.',
    'Emergency pain relief available 24/7.',
  ],
};