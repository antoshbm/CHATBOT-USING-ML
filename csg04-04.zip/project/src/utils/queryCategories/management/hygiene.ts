import { QueryCategory } from '../../types';

export const hygieneQueries: QueryCategory = {
  keywords: [
    'hygiene', 'cleaning', 'sanitation', 'sterilization',
    'infection control', 'cleanliness', 'disinfection',
    'waste management', 'medical waste', 'sanitizer'
  ],
  responses: [
    'Our hygiene protocols include:\n- Regular sanitization\n- Medical waste management\n- Infection control measures\n- Air quality monitoring',
    'We maintain strict cleaning schedules:\n- Hourly common area cleaning\n- Daily room sanitization\n- Continuous medical area sterilization',
    'All staff follow rigorous hand hygiene protocols.',
    'Medical waste is handled according to CDC and WHO guidelines.',
  ],
};