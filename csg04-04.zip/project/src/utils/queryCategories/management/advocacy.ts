import { QueryCategory } from '../../types';

export const patientAdvocacyQueries: QueryCategory = {
  keywords: [
    'patient advocacy', 'patient rights', 'healthcare advocacy',
    'medical rights', 'patient support', 'healthcare rights',
    'patient representation', 'medical advocacy'
  ],
  responses: [
    'Advocacy services include:\n- Rights protection\n- Care coordination\n- Complaint resolution\n- Support services',
    'Patient advocates help with:\n- Healthcare navigation\n- Communication\n- Resource access\n- Problem resolution',
    'Contact patient advocate: (555) 123-4646.',
    'Confidential support available.',
  ],
};