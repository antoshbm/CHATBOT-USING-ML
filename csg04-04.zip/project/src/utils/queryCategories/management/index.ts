export * from './staffing';
export * from './equipment';
export * from './beds';
export * from './hygiene';
export * from './quality';
export * from './inventory';
export * from './emergency';
export * from './compliance';
export * from './training';
export * from './scheduling';
export * from './maintenance';
export * from './security';
export * from './it';
export * from './finance';
export * from './research';

import { QueryCategory } from '../../types';
import { staffingQueries } from './staffing';
import { equipmentQueries } from './equipment';
import { bedManagementQueries } from './beds';
import { hygieneQueries } from './hygiene';
import { qualityControlQueries } from './quality';
import { inventoryQueries } from './inventory';
import { emergencyManagementQueries } from './emergency';
import { complianceQueries } from './compliance';
import { trainingQueries } from './training';
import { schedulingQueries } from './scheduling';
import { maintenanceQueries } from './maintenance';
import { securityQueries } from './security';
import { itManagementQueries } from './it';
import { financeQueries } from './finance';
import { researchManagementQueries } from './research';

export const managementQueries: QueryCategory = {
  keywords: [
    ...staffingQueries.keywords,
    ...equipmentQueries.keywords,
    ...bedManagementQueries.keywords,
    ...hygieneQueries.keywords,
    ...qualityControlQueries.keywords,
    ...inventoryQueries.keywords,
    ...emergencyManagementQueries.keywords,
    ...complianceQueries.keywords,
    ...trainingQueries.keywords,
    ...schedulingQueries.keywords,
    ...maintenanceQueries.keywords,
    ...securityQueries.keywords,
    ...itManagementQueries.keywords,
    ...financeQueries.keywords,
    ...researchManagementQueries.keywords,
    'hospital management', 'administration', 'operations'
  ],
  responses: [
    'Our hospital management system ensures efficient operations across all departments.',
    'For specific inquiries about hospital operations, please contact our administration office: (555) 123-4602.',
  ],
};