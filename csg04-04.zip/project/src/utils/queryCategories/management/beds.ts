import { QueryCategory } from '../../types';

export const bedManagementQueries: QueryCategory = {
  keywords: [
    'bed availability', 'room', 'ward', 'admission',
    'inpatient', 'ICU bed', 'private room',
    'hospital stay', 'overnight', 'accommodation'
  ],
  responses: [
    'Our hospital features:\n- Private rooms\n- Semi-private rooms\n- ICU units\n- Specialized care units',
    'Room amenities include:\n- Adjustable beds\n- Private bathrooms\n- TV/Entertainment\n- WiFi access',
    'For current bed availability, contact admissions: (555) 123-4600.',
    'ICU beds are managed 24/7 with priority for emergency cases.',
  ],
};