import { QueryCategory } from '../../types';

export const surgicalQueries: QueryCategory = {
  keywords: [
    'surgical precision', 'surgery protocol', 'operating room',
    'surgical safety', 'operation guidelines', 'surgical care',
    'pre-op', 'post-op', 'surgical procedure'
  ],
  responses: [
    'Surgical protocols include:\n- Pre-op checklist\n- Sterile technique\n- Equipment verification\n- Safety timeouts',
    'Operating room standards:\n- Team briefing\n- Site marking\n- Count procedures\n- Documentation',
    'For surgical scheduling: (555) 123-4641.',
    'Emergency surgery available 24/7.',
  ],
};