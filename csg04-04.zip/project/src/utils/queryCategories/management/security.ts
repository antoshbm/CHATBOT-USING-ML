import { QueryCategory } from '../../types';

export const securityQueries: QueryCategory = {
  keywords: [
    'security', 'hospital security', 'safety measures',
    'surveillance', 'access control', 'security staff',
    'security protocols', 'emergency security'
  ],
  responses: [
    'Security measures include:\n- 24/7 surveillance\n- Access control\n- Security patrols\n- Emergency response',
    'All areas monitored by security personnel.',
    'Visitor screening at all entrances.',
    'Security office: (555) 123-4636.',
  ],
};