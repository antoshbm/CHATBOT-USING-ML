import { QueryCategory } from '../../types';

export const equipmentQueries: QueryCategory = {
  keywords: [
    'equipment', 'medical devices', 'machines',
    'MRI', 'CT scan', 'X-ray', 'ultrasound',
    'diagnostic equipment', 'surgical equipment',
    'medical technology'
  ],
  responses: [
    'Our facility features state-of-the-art equipment including:\n- 3T MRI scanner\n- CT scanners\n- Digital X-ray systems\n- Ultrasound machines',
    'Advanced surgical suites equipped with:\n- Robotic surgery systems\n- Minimally invasive tools\n- Advanced monitoring equipment',
    'Diagnostic imaging services available:\n- MRI: 7 AM - 9 PM\n- CT scan: 24/7\n- X-ray: 24/7\nSchedule: (555) 123-4599.',
    'Emergency diagnostic equipment available 24/7.',
  ],
};