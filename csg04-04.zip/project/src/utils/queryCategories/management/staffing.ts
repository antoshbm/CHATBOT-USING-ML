import { QueryCategory } from '../../types';

export const staffingQueries: QueryCategory = {
  keywords: [
    'staff', 'doctor availability', 'nurse', 'shift',
    'on-call', 'medical team', 'personnel',
    'healthcare workers', 'duty hours', 'rotation'
  ],
  responses: [
    'Our medical staff includes:\n- Board-certified physicians\n- Registered nurses\n- Specialists\n- Support staff',
    'Medical teams are available 24/7 with:\n- Day shift: 7 AM - 7 PM\n- Night shift: 7 PM - 7 AM\n- On-call specialists',
    'Emergency department is fully staffed 24/7 with trauma-certified personnel.',
    'For specific doctor availability, please contact our scheduling desk: (555) 123-4598.',
  ],
};