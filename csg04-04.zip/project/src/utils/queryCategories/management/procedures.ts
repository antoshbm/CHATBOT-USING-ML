import { QueryCategory } from '../../types';

export const procedureProtocolQueries: QueryCategory = {
  keywords: [
    'procedure protocol', 'medical procedure', 'clinical protocol',
    'treatment procedure', 'standard procedure', 'protocol guidelines',
    'medical guidelines', 'clinical standards'
  ],
  responses: [
    'Protocol guidelines cover:\n- Standard procedures\n- Safety measures\n- Documentation\n- Follow-up care',
    'Procedure requirements:\n- Patient consent\n- Pre-procedure checks\n- Post-procedure care\n- Monitoring',
    'For protocol information: (555) 123-4644.',
    'Emergency procedures available 24/7.',
  ],
};