import { QueryCategory } from '../../types';

export const researchManagementQueries: QueryCategory = {
  keywords: [
    'research programs', 'clinical trials', 'medical research',
    'study protocols', 'research ethics', 'trial management',
    'research compliance', 'study coordination'
  ],
  responses: [
    'Research programs include:\n- Clinical trials\n- Medical studies\n- Treatment research\n- Data analysis',
    'All research follows ethical guidelines.',
    'IRB approval required for studies.',
    'Research office: (555) 123-4639.',
  ],
};