import { QueryCategory } from '../../types';

export const estimateQueries: QueryCategory = {
  keywords: [
    'estimate', 'quote', 'cost estimate', 'price check',
    'procedure cost', 'treatment cost', 'check-up cost',
    'consultation fee', 'service charges', 'pricing'
  ],
  responses: [
    'Common service estimates:\n- General check-up: $150-$500\n- Specialist consultation: $200-$400\n- Basic blood work: $100-$300\nFinal costs may vary based on specific tests.',
    'For a detailed cost estimate, please provide:\n1. Type of service needed\n2. Insurance information\n3. Any specific tests required\nContact our pricing team: (555) 123-4578',
    'Self-pay discounts available:\n- 15% early payment discount\n- Payment plans available\n- Financial assistance for eligible patients',
    'Request a detailed estimate through:\n1. Patient portal\n2. Billing department\n3. Insurance desk\nResponse time: 1-2 business days',
  ],
};