import type { ChatResponse } from '../types';
import { 
  appointmentQueries,
  emergencyQueries,
  billingQueries,
  facilityQueries,
  prescriptionQueries,
  covidQueries,
  specialtyQueries,
  recordQueries,
  visitingQueries,
  doctorQueries,
  emergencyContactQueries,
  diseaseQueries,
  symptomQueries,
  wellnessQueries,
  registrationQueries,
  ambulanceQueries,
  parkingQueries,
  timingQueries,
  managementQueries,
  patientQueries
} from './queryCategories';

const allQueries = {
  appointments: appointmentQueries,
  emergency: emergencyQueries,
  billing: billingQueries,
  facilities: facilityQueries,
  prescriptions: prescriptionQueries,
  covid: covidQueries,
  specialties: specialtyQueries,
  records: recordQueries,
  visiting: visitingQueries,
  doctors: doctorQueries,
  emergencyContacts: emergencyContactQueries,
  diseases: diseaseQueries,
  symptoms: symptomQueries,
  wellness: wellnessQueries,
  registration: registrationQueries,
  ambulance: ambulanceQueries,
  parking: parkingQueries,
  timings: timingQueries,
  management: managementQueries,
  patients: patientQueries
};

// Prioritized categories that should be checked first
const priorityCategories = ['emergency', 'ambulance', 'emergencyContacts'];

export function generateResponse(input: string): ChatResponse {
  const lowercaseInput = input.toLowerCase();
  
  // Check priority categories first
  for (const category of priorityCategories) {
    const data = allQueries[category];
    if (data.keywords.some(keyword => lowercaseInput.includes(keyword))) {
      return {
        text: data.responses[Math.floor(Math.random() * data.responses.length)],
        category,
      };
    }
  }
  
  // Check all other categories
  for (const [category, data] of Object.entries(allQueries)) {
    if (!priorityCategories.includes(category) && 
        data.keywords.some(keyword => lowercaseInput.includes(keyword))) {
      return {
        text: data.responses[Math.floor(Math.random() * data.responses.length)],
        category,
      };
    }
  }
  
  return {
    text: "I apologize, but I'm not sure how to help with that specific query. Would you like to speak with a human representative?",
    category: 'unknown',
  };
}