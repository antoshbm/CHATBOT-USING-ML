export interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

export interface User {
  username: string;
  role: 'staff' | 'patient';
}

export interface ChatResponse {
  text: string;
  category: string;
}

export interface QueryCategory {
  keywords: string[];
  responses: string[];
}